namespace BuberDinner.Api.Http;

public static class HttpContextItemKeys
{
    public const string Errors = "Errors";
}