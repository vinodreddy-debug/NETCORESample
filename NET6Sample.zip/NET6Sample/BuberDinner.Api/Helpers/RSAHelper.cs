using System.Security.Cryptography;
using System.Text;

namespace BuberDinner.Api.Helpers;


public class RSAHelper
{
    private readonly string _publicKey;

    private static UnicodeEncoding _encoder = new UnicodeEncoding();

    public RSAHelper(string publicKey)
    {
        _publicKey = publicKey;
    }

    public string EncryptData(string data)
    {
        var rsa = new RSACryptoServiceProvider();
        var publicKeyBytes = Convert.FromBase64String(_publicKey);
        rsa.ImportSubjectPublicKeyInfo(publicKeyBytes, out _);
        var dataToEncrypt = _encoder.GetBytes(data);
        var encryptedByteArray = rsa.Encrypt(dataToEncrypt, false).ToArray();

        return Convert.ToBase64String(encryptedByteArray);
    }
}