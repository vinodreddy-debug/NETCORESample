using System.Text.Json.Serialization;
using BuberDinner.Application;
using BuberDinner.Infrastructure;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using BuberDinner.Api.Common.Errors;
using WatchDog;


var builder = WebApplication.CreateBuilder(args);
{
    builder.Services.AddApplication();
    builder.Services.AddInfrastructure(builder.Configuration);

    //add this to validate incoming token
    // builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    //       .AddJwtBearer(options =>
    //       {
    //           options.TokenValidationParameters = new TokenValidationParameters
    //           {
    //               ValidateIssuer = true,
    //               ValidateAudience = true,
    //               ValidateIssuerSigningKey = true,
    //               ValidIssuer = builder.Configuration.GetValue<string>("JwtSettings:Issuer"),
    //               ValidAudience = builder.Configuration.GetValue<string>("JwtSettings:Audience"),
    //               IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration.GetValue<string>("JwtSettings:Secret")))
    //           };
    //           options.Events = new JwtBearerEvents
    //           {
    //               OnAuthenticationFailed = context =>
    //               {
    //                   if (context.Exception.GetType() == typeof(SecurityTokenExpiredException))
    //                   {
    //                       context.Response.Headers.Add("Token-Expired", "true");
    //                       //context.Response.Body = "Token Expired. PLease provide valid token";
    //                   }
    //                   return Task.CompletedTask;
    //               }
    //           };
    //       });
    //builder.Services.AddControllers(options=>options.Filters.Add<ErrorHandlingFilterAttribute>());
    builder.Services.AddControllers().AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
    });
    builder.Services.AddSingleton<ProblemDetailsFactory, BubberDinnerProblemDetailsFactory>();
    var path = Directory.GetCurrentDirectory();
    var dtre = builder.Configuration;
    //builder.Logging.AddFile($"{path}\\Logs\\Log.txt");
    builder.Services.AddWatchDogServices();
};

var app = builder.Build();
{
    //app.UseMiddleware<ErrorHandlingMiddleware>();
    app.UseExceptionHandler("/error");
    app.UseHttpsRedirection();

    app.UseWatchDogExceptionLogger();
    app.UseWatchDog(opt =>
    {
        opt.WatchPageUsername = "vinod";
        opt.WatchPagePassword = "vinod";
    });

    //use these two for token based authentication
    // app.UseAuthentication();
    // app.UseAuthorization();

    app.MapControllers();
    app.Run();
};

