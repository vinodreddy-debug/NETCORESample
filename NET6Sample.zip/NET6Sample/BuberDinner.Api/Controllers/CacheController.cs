using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using BuberDinner.Api.Helpers;
using BuberDinner.Contracts.Cache;
using Microsoft.AspNetCore.Mvc;

namespace BuberDinner.Api.Controllers;

[ApiController]
[Route("test")]
public class CacheController : ApiController
{
    private readonly TokenHelper _tokenHelper;

    public CacheController(IConfiguration configuration)
    {
        this._tokenHelper = new TokenHelper(configuration);
    }

    [HttpPost("cache")]
    public IActionResult cache(dynamic data)
    {

        string publickey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA0eOeVrzt8iHHP/SCvFq6BVJNVMKeIK/0xpptc7LFvo+qaDl3lQNAigHrKTYajzf83OIOousR0lyvyjznfn30bqos6RDFOKBsOugmvrkWAtQbdC19hGjer27bjLlMeHb2R3RheUGcfmG4FQ+VLpUlDAkNkuwkjlP28Gsv7/UaHROoequ7n198F21gRyI/IyxT6jTbgocW3oYqBb9IBtGunsa3VKMBaqo6kIx43Cp15HSA6Rz7nv0XSzoKOoi2kI5t9z4hi73eHJkFYkcZvkqH5NCG4qnHmR9x6phGS0Uv673SrhVKAE48YRSjHjULTf5DsMT9TMcpi/NzY/I3I1kagwIDAQAB";

        RSAHelper rsaHelper = new RSAHelper(publicKey: publickey);

        string token = rsaHelper.EncryptData("test");

        return Ok(token);


        // string success = "";
        // success = "{ \"filed\": \"0d5bd590-86b5-4281-9ef7-924c15190273\", \"FirstName\": \"1sssqwer\", \"LastName\": \"sss2\", \"EmailId\": \"ssss3@infor.com\", \"ClientPrincipal\": \"0d5bd590-86b5-4281-9ef7-924c15190273\"}";


        // return Content(success, "application/json", Encoding.UTF8);

        //string token = _tokenHelper.GenerateToken(1234);

        //bool IsValidToken = _tokenHelper.ValidateToken(token);


        // JsonDocument doc= JsonDocument.Parse(data);

        // foreach (JsonElement item in doc.RootElement.EnumerateArray())
        // {
        //    string tt= item.ToString();
        // }

        //  return Ok();

        // string  dddt="";

        // try
        // {
        //     JsonSerializerOptions options = new()
        //     {
        //         DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
        //     };

        //     CacheRequest cact = JsonSerializer.Deserialize<CacheRequest>(data, options);
        //     string outp = string.Empty;
        //     foreach (Attri request in cact.Request.attributes)
        //     {
        //         string updatedLeneth = "";
        //         if (cact.Body.RootElement.TryGetProperty(request.Name, out JsonElement element))
        //         {
        //             //cact.Body.RootElement.TryGetProperty(request.Length.ToString(), out JsonElement value);

        //             switch (request.Type)
        //             {
        //                 case "LIST":
        //                     List<string> recordAray = new List<string>();
        //                     var filedValue = "";
        //                     //var subVal = element.TryGetProperty(subrItem.Name, out JsonElement element1);
        //                     var arrayenumerator = element.EnumerateArray();
        //                     JsonElement element2;
        //                     foreach (JsonElement ele in arrayenumerator)
        //                     {
        //                         var recordStr = "";
        //                         foreach (Attri subrItem in request.LIST.attributes)
        //                         {

        //                             if (ele.TryGetProperty(subrItem.Name, out element2)) ;
        //                             {
        //                                 switch (subrItem.Type)
        //                                 {
        //                                     case "N":
        //                                         filedValue = element2.GetInt32().ToString().PadLeft(subrItem.Length, '0');
        //                                         recordStr += filedValue;
        //                                         continue;
        //                                     case "D":
        //                                         filedValue = element2.GetInt32().ToString().PadRight(subrItem.Length - 2, '0') + "00";
        //                                         recordStr += filedValue;
        //                                         continue;
        //                                     default:
        //                                         filedValue = element2.GetString().PadLeft(subrItem.Length, ' ');
        //                                         recordStr += filedValue;
        //                                         continue;
        //                                 }
        //                             }
        //                         }
        //                         recordAray.Add(recordStr);

        //                     }

        //                     var blankSpaceCount = request.LIST.RecLength * (request.LIST.Max - element.GetArrayLength());
        //                     //dddt += String.Join("", recordAray.ToArray());
        //                     updatedLeneth = String.Concat(element.GetArrayLength).PadLeft(request.Length, '0') + String.Join("", recordAray.ToArray());
        //                     //updatedLeneth =  String.Join("", recordAray.ToArray());
        //                     var blankSpace = "";
        //                     for (var i = 0; i < blankSpaceCount; i++)
        //                     {
        //                         blankSpace += " ";
        //                     }
        //                     updatedLeneth += blankSpace;
        //                     outp += updatedLeneth;
        //                     continue;
        //                 case "N":
        //                     updatedLeneth = element.GetInt32().ToString().PadLeft(request.Length, '0');
        //                     outp += updatedLeneth;
        //                     continue;
        //                 case "D":
        //                     updatedLeneth = element.GetString().PadLeft(request.Length - 2, '0') + "00";
        //                     outp += updatedLeneth;
        //                     continue;
        //                 default:
        //                     updatedLeneth = element.GetString().PadRight(request.Length, ' ');
        //                     outp += updatedLeneth;
        //                     continue;
        //             }
        //         }
        //         else
        //         {
        //             // attribute not found
        //             switch (request.Type)
        //             {
        //                 case "D":
        //                     updatedLeneth = element.GetString().PadLeft(request.Length - 2, ' ') + " ";
        //                     outp += updatedLeneth;
        //                     continue;
        //                 default:
        //                     updatedLeneth = string.Empty.PadRight(request.Length, ' ');
        //                     outp += updatedLeneth;
        //                     continue;
        //             }
        //         }
        //     }
        //     return Ok( JsonSerializer.Serialize(outp));
        // }
        // catch (System.Exception ex)
        // {
        //     return BadRequest("Oops! somethign wrong.");
        // }
    }
}

