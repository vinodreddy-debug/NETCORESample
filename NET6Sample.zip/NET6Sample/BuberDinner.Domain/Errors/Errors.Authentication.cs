using ErrorOr;

namespace BubeeDinner.Domain.Errors;

public static partial class Errors
{
    public static class Authentication
    {
        public static Error InvalidCredentials => Error.Validation(code: "Auth.InvalidCred", description: "Invalid Credentials");
        public static Error UserNotExists => Error.NotFound(code: "User.NotFound", description: "User with given email addresses doesn't exists.");

    }
}