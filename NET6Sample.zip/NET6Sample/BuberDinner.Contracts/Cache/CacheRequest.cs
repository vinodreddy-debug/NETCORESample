using System.Text.Json;
using System.Text.Json.Serialization;

namespace BuberDinner.Contracts.Cache
{
    public class Attri
    {
        [JsonPropertyName("name")]
        public string Name { get; set; }

        [JsonPropertyName("length")]
        public int Length { get; set; }

        [JsonPropertyName("type")]
        public string Type { get; set; }

        [JsonPropertyName("mandatory")]
        public bool Mandatory { get; set; }

        [JsonPropertyName("start")]
        public int Start { get; set; }

        [JsonPropertyName("LIST")]
        public LIST LIST { get; set; }
    }

    public class LIST
    {
        [JsonPropertyName("recLength")]
        public int RecLength { get; set; }

        [JsonPropertyName("max")]
        public int Max { get; set; }

        [JsonPropertyName("attributes")]
        public List<Attri> attributes { get; set; }
    }

    public class Req
    {
        [JsonPropertyName("Id")]
        public string Id { get; set; }

        [JsonPropertyName("Ver")]
        public string Ver { get; set; }

        [JsonPropertyName("attributes")]
        public List<Attri> attributes { get; set; }
    }

    public class CacheRequest
    {
        [JsonPropertyName("request")]
        public Req Request { get; set; }

        [JsonPropertyName("body")]
        public JsonDocument Body { get; set; }

        [JsonPropertyName("response")]
        public string Response { get; set; }
    }
}