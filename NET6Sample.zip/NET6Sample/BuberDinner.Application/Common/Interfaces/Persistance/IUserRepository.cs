using BubeeDinner.Domain.Entities;

namespace BubeeDinner.Application.Common.Interfaces.Persistance;

public interface IUserRepository
{
    User? GetUserByEmail(string email);
    void AddUser(User user);
}